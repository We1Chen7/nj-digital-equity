# Initial descriptive findings

ACS period: 2020-2024. Tracts: 2,181; counties: 21.
Tracts with positive household denominators: 2,166.
State households (estimated): 3,507,701.

Using the official state row, 5.39% of households
had no internet access, 4.06% had no computing device,
and 10.34% had a cellular-only internet subscription.
The unweighted tract correlation between poverty and no internet access was
0.462. This is a descriptive ecological association, not causation.

The NJ resource directory contains 614 raw records. Consult
asset_quality_summary.csv before counting service sites. Directory observations
are not capacity measurements, and a zero directory count would not establish
absence of services. Raw count margins of error are retained. Derived percentages
do not yet have calculated confidence intervals.

FCC availability was not downloaded. No resource-distance or causal model is
reported. The directory snapshot and ACS reference period differ.
